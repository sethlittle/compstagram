package comp110;

public class ColorTests {

	public static void main(String[] args) {

		Color color = new Color(0.44, -1.2, 0.85);

		// TODO: Test your work as you add functionality in Part 1.

		System.out.println(color.getRed());
		System.out.println(color.getGreen());
		System.out.println(color.getBlue());

		Color newColor = color.copy();

		newColor.setRed(0.46);
		newColor.setGreen(0.1);
		newColor.setBlue(0.89);

		System.out.println(" " + newColor.getRed() + " , " + newColor.getGreen() + " , " + newColor.getBlue() + " ");
		System.out.println(" " + color.getRed() + " , " + color.getGreen() + " , " + color.getBlue() + " ");

	}

}
