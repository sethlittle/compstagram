package comp110;

/**
 * Author: Seth Little
 *
 * ONYEN: sethl
 *
 * Collaborator(s):
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been received
 * or given in the completion of this work. I certify that I understand and
 * could now rewrite on my own, without assistance from collaborators or course
 * staff, the problem set code I am submitting.
 */
public class Image {

	// TODO: 2.1 Declare _pixels array
	private Color[][] _pixels;

	// TODO: 2.2 Declare & define constructor
	public Image(int width, int height) {
		_pixels = new Color[width][height];

		for (int x = 0; x < _pixels.length; x++) {
			for (int y = 0; y < _pixels[0].length; y++) {
				_pixels[x][y] = new Color(1.0, 1.0, 1.0);
			}
		}
	}

	// TODO: 2.3 Define width / height getters

	public int getWidth() {
		return _pixels.length;
	}

	public int getHeight() {
		return _pixels[0].length;
	}

	// TODO: 2.4 Define pixel getter/setter

	public Color getPixel(int x, int y) {
		return _pixels[x][y]; // THIS
	}

	public void setPixel(int x, int y, Color color) {
		_pixels[x][y] = color; // THIS
	}

	// TODO: 2.5 Define copy method

	public Image copy() {
		int width = this.getWidth();
		int height = this.getHeight();

		Image image = new Image(width, height);

		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				Color now = _pixels[x][y];
				Color pixel = new Color(now.getRed(), now.getGreen(), now.getBlue());
				image.setPixel(x, y, pixel);
			}
		}

		return image;
	}

}
