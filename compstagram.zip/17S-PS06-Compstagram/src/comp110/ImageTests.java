package comp110;

public class ImageTests {

	public static void main(String[] args) {

		// TODO: Test your work as you add functionality in Part 2.
		Image image = new Image(13, 1);
		Color white = new Color(1.0, 1.0, 1.0);
		System.out.println(image.getHeight());
		System.out.println(image.getWidth());

		image.setPixel(0, 0, white); // do something about this
		System.out.println(image.getPixel(0, 0));

		Image newImage = image.copy();

		System.out.println(newImage.getHeight());
		System.out.println(newImage.getWidth());

		System.out.println(image.getPixel(0, 0));
		System.out.println(newImage.getPixel(0, 0));

	}

}
