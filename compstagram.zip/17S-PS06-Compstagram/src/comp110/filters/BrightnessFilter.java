package comp110.filters;

import comp110.Image;
import comp110.Color;

/**
 * Author: Seth Little
 *
 * ONYEN: sethl
 *
 * Collaborator(s):
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been received
 * or given in the completion of this work. I certify that I understand and
 * could now rewrite on my own, without assistance from collaborators or course
 * staff, the problem set code I am submitting.
 */
public class BrightnessFilter implements Filter {

	public Image process(Image input) {
		// TODO
		Image output = input.copy();

		for (int x = 0; x < output.getWidth(); x++) {
			for (int y = 0; y < output.getHeight(); y++) {

				Color pixel = output.getPixel(x, y);

				double brightness = (_amount - 0.5) * 2.0;

				double r = pixel.getRed();
				double g = pixel.getGreen();
				double b = pixel.getBlue();

				double deltaR = brightness * r;
				double deltaG = brightness * g;
				double deltaB = brightness * b;

				double red = r + deltaR;
				double green = g + deltaG;
				double blue = b + deltaB;

				pixel.setRed(red);
				pixel.setGreen(green);
				pixel.setBlue(blue);

			}
		}

		return output;
	}

	/*
	 * 110-provided code below. You should understand what it all does but you
	 * should not modify.
	 */

	private double _amount;

	public BrightnessFilter(double amount) {
		_amount = amount;
	}

	public String toString() {
		return "Brightness";
	}

	public double getAmount() {
		return _amount;
	}

	public void setAmount(double amount) {
		_amount = amount;
	}

}