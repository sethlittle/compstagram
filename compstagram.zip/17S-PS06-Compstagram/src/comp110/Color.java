package comp110;

/**
 * Author: Seth Little
 *
 * ONYEN: sethl
 *
 * Collaborator(s):
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been received
 * or given in the completion of this work. I certify that I understand and
 * could now rewrite on my own, without assistance from collaborators or course
 * staff, the problem set code I am submitting.
 */
public class Color {

	// TODO: 1.1 Declare instance variables
	private double _red;
	private double _green;
	private double _blue;

	// TODO: 1.4 Declare & define constructor

	public Color(double red, double green, double blue) {
		this.setRed(red);
		this.setGreen(green);
		this.setBlue(blue);
	}

	// TODO: 1.2 Declare & define getters

	public double getRed() {
		return _red;
	}

	public double getGreen() {
		return _green;
	}

	public double getBlue() {
		return _blue;
	}

	// TODO: 1.3 Declare & define setters

	public void setRed(double value) {
		value = this.inRange(value);
		_red = value;
	}

	public void setGreen(double value) {
		value = this.inRange(value);
		_green = value;
	}

	public void setBlue(double value) {
		value = this.inRange(value);
		_blue = value;
	}

	private double inRange(double value) {
		if (value < 0) {
			return 0.0;
		} else if (value > 1.0) {
			return 1.0;
		} else {
			return value;
		}
	}

	// TODO: 1.5 Declare & define copy method

	public Color copy() {
		Color color = new Color(_red, _green, _blue);
		return color;
	}

}